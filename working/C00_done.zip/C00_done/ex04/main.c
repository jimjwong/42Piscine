#include <unistd.h>

void ft_is_negative(int n);

int main(void)
{
  ft_is_negative(-5);
  ft_is_negative(10);
  ft_is_negative(-2);

  return(0);
}
