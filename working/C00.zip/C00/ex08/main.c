#include <unistd.h>

void ft_print_combn(int n);

int main(void)
{
	ft_print_combn(4);
	return (0);
}
